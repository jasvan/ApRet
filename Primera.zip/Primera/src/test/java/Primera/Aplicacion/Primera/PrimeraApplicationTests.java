package Primera.Aplicacion.Primera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeraApplicationTests {

	@Test
	void contextLoads() {
	}

}
